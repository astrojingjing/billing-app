'use client';

import { useState, useEffect, useRef } from 'react';
import * as echarts from 'echarts';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Edit, Trash2 } from 'lucide-react';

interface PlatformData {
  id: string;
  name: string;
  revenue: number;
  month: string;
}

interface MonthlySummary {
  month: string;
  totalRevenue: number;
}

export default function CosmeticsRevenuePage() {
  const [platforms, setPlatforms] = useState<PlatformData[]>([]);
  const [monthlySummary, setMonthlySummary] = useState<MonthlySummary[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<PlatformData | null>(null);
  const [formData, setFormData] = useState({ name: '', revenue: '', month: '' });
  const chartRef = useRef<HTMLDivElement>(null);
  const chartInstance = useRef<echarts.ECharts | null>(null);

  // 从 localStorage 加载数据
  useEffect(() => {
    const savedData = localStorage.getItem('cosmeticsRevenueData');
    if (savedData) {
      const parsed = JSON.parse(savedData);
      setPlatforms(parsed);
      calculateMonthlySummary(parsed);
    } else {
      // 默认示例数据
      const defaultData: PlatformData[] = [
        { id: '1', name: '天猫', revenue: 150000, month: '2025-01' },
        { id: '2', name: '京东', revenue: 120000, month: '2025-01' },
        { id: '3', name: '抖音', revenue: 180000, month: '2025-01' },
        { id: '4', name: '小红书', revenue: 95000, month: '2025-01' },
        { id: '5', name: '拼多多', revenue: 110000, month: '2025-01' },
        { id: '6', name: '天猫', revenue: 165000, month: '2025-02' },
        { id: '7', name: '京东', revenue: 135000, month: '2025-02' },
        { id: '8', name: '抖音', revenue: 195000, month: '2025-02' },
        { id: '9', name: '小红书', revenue: 105000, month: '2025-02' },
        { id: '10', name: '拼多多', revenue: 125000, month: '2025-02' },
      ];
      setPlatforms(defaultData);
      calculateMonthlySummary(defaultData);
      localStorage.setItem('cosmeticsRevenueData', JSON.stringify(defaultData));
    }
  }, []);

  // 计算月度汇总
  const calculateMonthlySummary = (data: PlatformData[]) => {
    const summary = data.reduce((acc, item) => {
      if (!acc[item.month]) {
        acc[item.month] = 0;
      }
      acc[item.month] += item.revenue;
      return acc;
    }, {} as Record<string, number>);

    const sortedSummary = Object.entries(summary)
      .map(([month, totalRevenue]) => ({ month, totalRevenue }))
      .sort((a, b) => a.month.localeCompare(b.month));

    setMonthlySummary(sortedSummary);
  };

  // 更新图表
  useEffect(() => {
    if (chartRef.current && monthlySummary.length > 0) {
      if (!chartInstance.current) {
        chartInstance.current = echarts.init(chartRef.current);
      }

      const option = {
        title: {
          text: '月度收入分布',
          left: 'center',
          top: 20,
          textStyle: {
            fontSize: 20,
            fontWeight: 'bold',
            color: '#f0abfc',
            fontFamily: 'sans-serif'
          }
        },
        tooltip: {
          trigger: 'item',
          formatter: '{b}\n¥{c}',
          backgroundColor: 'rgba(139, 92, 246, 0.9)',
          borderColor: '#a78bfa',
          textStyle: {
            color: '#ffffff',
            fontSize: 14
          },
          padding: [12, 16],
          borderRadius: 8
        },
        legend: {
          orient: 'vertical',
          left: 'left',
          top: 'middle',
          textStyle: {
            color: '#e9d5ff',
            fontSize: 13
          }
        },
        series: [
          {
            name: '月度收入',
            type: 'pie',
            radius: ['45%', '75%'],
            center: ['60%', '50%'],
            avoidLabelOverlap: false,
            itemStyle: {
              borderRadius: 15,
              borderColor: '#1e1b4b',
              borderWidth: 3,
              shadowBlur: 20,
              shadowColor: 'rgba(192, 132, 252, 0.5)'
            },
            label: {
              show: true,
              position: 'outside',
              formatter: function(params: any) {
                const percentage = ((params.value / monthlySummary.reduce((sum, item) => sum + item.totalRevenue, 0)) * 100).toFixed(1);
                return `${params.name}\n¥${params.value.toLocaleString()}\n${percentage}%`;
              },
              color: '#e9d5ff',
              fontSize: 12,
              fontWeight: 'bold'
            },
            labelLine: {
              show: true,
              length: 20,
              length2: 20,
              smooth: true,
              lineStyle: {
                color: '#c4b5fd',
                width: 2
              }
            },
            emphasis: {
              label: {
                show: true,
                fontSize: 16,
                fontWeight: 'bold',
                color: '#ffffff'
              },
              itemStyle: {
                shadowBlur: 30,
                shadowColor: 'rgba(192, 132, 252, 0.8)',
                borderWidth: 4
              },
              scale: true,
              scaleSize: 10
            },
            data: monthlySummary.map((item, index) => {
              const colors = [
                { start: '#f472b6', end: '#ec4899' },   // pink
                { start: '#a78bfa', end: '#8b5cf6' },   // purple
                { start: '#60a5fa', end: '#3b82f6' },   // blue
                { start: '#34d399', end: '#10b981' },   // green
                { start: '#fbbf24', end: '#f59e0b' },   // amber
                { start: '#fb7185', end: '#ef4444' },   // red
              ];
              const colorIndex = index % colors.length;
              return {
                value: item.totalRevenue,
                name: `${item.month}`,
                itemStyle: {
                  color: {
                    type: 'linear',
                    x: 0,
                    y: 0,
                    x2: 1,
                    y2: 1,
                    colorStops: [
                      { offset: 0, color: colors[colorIndex].start },
                      { offset: 1, color: colors[colorIndex].end }
                    ]
                  }
                }
              };
            })
          }
        ]
      };

      chartInstance.current.setOption(option);

      // 响应式调整
      const handleResize = () => {
        chartInstance.current?.resize();
      };
      window.addEventListener('resize', handleResize);
      return () => window.removeEventListener('resize', handleResize);
    }
  }, [monthlySummary]);

  // 保存数据
  const saveData = (data: PlatformData[]) => {
    setPlatforms(data);
    localStorage.setItem('cosmeticsRevenueData', JSON.stringify(data));
    calculateMonthlySummary(data);
  };

  // 打开新建对话框
  const handleOpenDialog = () => {
    setEditingItem(null);
    setFormData({ name: '', revenue: '', month: '' });
    setIsDialogOpen(true);
  };

  // 打开编辑对话框
  const handleEdit = (item: PlatformData) => {
    setEditingItem(item);
    setFormData({ name: item.name, revenue: item.revenue.toString(), month: item.month });
    setIsDialogOpen(true);
  };

  // 删除项目
  const handleDelete = (id: string) => {
    if (confirm('确定要删除这条记录吗？')) {
      const newData = platforms.filter(item => item.id !== id);
      saveData(newData);
    }
  };

  // 保存表单
  const handleSave = () => {
    if (!formData.name || !formData.revenue || !formData.month) {
      alert('请填写完整信息');
      return;
    }

    const revenue = parseFloat(formData.revenue);
    if (isNaN(revenue) || revenue < 0) {
      alert('请输入有效的收入金额');
      return;
    }

    if (editingItem) {
      // 编辑模式
      const newData = platforms.map(item =>
        item.id === editingItem.id
          ? { ...item, name: formData.name, revenue, month: formData.month }
          : item
      );
      saveData(newData);
    } else {
      // 新建模式
      const newItem: PlatformData = {
        id: Date.now().toString(),
        name: formData.name,
        revenue,
        month: formData.month
      };
      saveData([...platforms, newItem]);
    }

    setIsDialogOpen(false);
  };

  // 按月份排序
  const sortedPlatforms = [...platforms].sort((a, b) => b.month.localeCompare(a.month));

  return (
    <div className="min-h-screen bg-gradient-to-br from-fuchsia-900 via-purple-900 to-indigo-900 p-6 relative overflow-hidden">
      {/* 背景装饰 */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-pink-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-1/4 left-1/3 w-96 h-96 bg-indigo-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-pink-300 via-purple-300 to-indigo-300 bg-clip-text text-transparent mb-2 drop-shadow-lg">
            化妆品平台收益统计
          </h1>
          <p className="text-purple-200 text-lg tracking-wider">COSMETICS PLATFORM REVENUE</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* 左侧：平台收入列表 */}
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-6 border border-white/20">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold bg-gradient-to-r from-pink-300 to-purple-300 bg-clip-text text-transparent">
                平台收入明细
              </h2>
              <div className="flex gap-2">
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button 
                      onClick={handleOpenDialog} 
                      className="flex items-center gap-2 bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white shadow-lg shadow-purple-500/30 transition-all duration-300 hover:scale-105"
                    >
                      <Plus className="w-4 h-4" />
                      新建
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-gradient-to-br from-white/90 to-purple-50/90 backdrop-blur-xl border-purple-200 shadow-2xl">
                    <DialogHeader>
                      <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
                        {editingItem ? '编辑记录' : '新建记录'}
                      </DialogTitle>
                    </DialogHeader>
                    <div className="space-y-5 py-4">
                      <div>
                        <Label htmlFor="platform" className="text-purple-700 font-semibold">平台名称</Label>
                        <Input
                          id="platform"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          placeholder="例如：天猫、京东、抖音"
                          className="mt-2 border-purple-200 focus:border-purple-400 focus:ring-purple-200"
                        />
                      </div>
                      <div>
                        <Label htmlFor="revenue" className="text-purple-700 font-semibold">收入金额（元）</Label>
                        <Input
                          id="revenue"
                          type="number"
                          value={formData.revenue}
                          onChange={(e) => setFormData({ ...formData, revenue: e.target.value })}
                          placeholder="例如：150000"
                          className="mt-2 border-purple-200 focus:border-purple-400 focus:ring-purple-200"
                        />
                      </div>
                      <div>
                        <Label htmlFor="month" className="text-purple-700 font-semibold">月份</Label>
                        <Input
                          id="month"
                          type="month"
                          value={formData.month}
                          onChange={(e) => setFormData({ ...formData, month: e.target.value })}
                          className="mt-2 border-purple-200 focus:border-purple-400 focus:ring-purple-200"
                        />
                      </div>
                      <Button 
                        onClick={handleSave} 
                        className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white shadow-lg shadow-purple-500/30 transition-all duration-300"
                      >
                        保存
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            <div className="overflow-x-auto rounded-xl">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gradient-to-r from-pink-500/20 to-purple-500/20 hover:from-pink-500/30 hover:to-purple-500/30">
                    <TableHead className="text-purple-100 font-bold text-base">平台名称</TableHead>
                    <TableHead className="text-purple-100 font-bold text-base">收入（元）</TableHead>
                    <TableHead className="text-purple-100 font-bold text-base">月份</TableHead>
                    <TableHead className="text-purple-100 font-bold text-base text-center">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sortedPlatforms.map((item, index) => (
                    <TableRow 
                      key={item.id} 
                      className="border-b border-purple-100/20 hover:bg-white/10 transition-all duration-300 hover:scale-[1.01]"
                    >
                      <TableCell className="font-medium text-purple-100">{item.name}</TableCell>
                      <TableCell className="text-pink-300 font-semibold">
                        ¥{item.revenue.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-purple-200">{item.month}</TableCell>
                      <TableCell className="text-center">
                        <div className="flex justify-center gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(item)}
                            className="hover:bg-pink-500/20 hover:text-pink-300 transition-all duration-300"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(item.id)}
                            className="hover:bg-red-500/20 hover:text-red-300 transition-all duration-300"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <div className="mt-6 pt-6 border-t border-purple-200/30 bg-gradient-to-r from-pink-500/10 to-purple-500/10 rounded-xl p-4">
              <div className="flex justify-between items-center">
                <span className="text-xl font-semibold text-purple-100">总计收入</span>
                <span className="text-2xl font-bold bg-gradient-to-r from-pink-300 via-purple-300 to-indigo-300 bg-clip-text text-transparent">
                  ¥{monthlySummary.reduce((sum, item) => sum + item.totalRevenue, 0).toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* 右侧：月度汇总和图表 */}
          <div className="space-y-8">
            {/* 月度汇总表 */}
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold bg-gradient-to-r from-pink-300 to-purple-300 bg-clip-text text-transparent mb-6">
                月度汇总
              </h2>
              <div className="overflow-x-auto rounded-xl">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gradient-to-r from-indigo-500/20 to-purple-500/20 hover:from-indigo-500/30 hover:to-purple-500/30">
                      <TableHead className="text-purple-100 font-bold text-base">月份</TableHead>
                      <TableHead className="text-purple-100 font-bold text-base text-right">总收入（元）</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {monthlySummary.map((item) => (
                      <TableRow 
                        key={item.month}
                        className="border-b border-purple-100/20 hover:bg-white/10 transition-all duration-300"
                      >
                        <TableCell className="font-medium text-purple-100">{item.month}</TableCell>
                        <TableCell className="text-right font-semibold bg-gradient-to-r from-pink-300 via-purple-300 to-indigo-300 bg-clip-text text-transparent">
                          ¥{item.totalRevenue.toLocaleString()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            {/* 3D饼图 */}
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold bg-gradient-to-r from-pink-300 to-purple-300 bg-clip-text text-transparent mb-6">
                月度收入可视化
              </h2>
              <div ref={chartRef} style={{ width: '100%', height: '400px' }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
